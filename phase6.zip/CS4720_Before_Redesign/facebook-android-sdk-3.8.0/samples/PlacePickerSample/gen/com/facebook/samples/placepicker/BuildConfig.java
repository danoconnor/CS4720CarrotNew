/** Automatically generated file. DO NOT MODIFY */
package com.facebook.samples.placepicker;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}