/** Automatically generated file. DO NOT MODIFY */
package com.facebook.samples.rps;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}