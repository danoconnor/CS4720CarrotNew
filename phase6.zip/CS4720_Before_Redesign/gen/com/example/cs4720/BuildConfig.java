/** Automatically generated file. DO NOT MODIFY */
package com.example.cs4720;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}